﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Postage.Tests
{
    [TestClass]
    public class PostageTest
    {
        [TestMethod]
        public void HeavyTestCategory_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(12.00M, 213.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Heavy";
            Assert.AreEqual(expected, ipostage.Category, "HeavyTestCategory_Test, failed");
        }
        [TestMethod]
        public void SmallTestCategory_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(10.00M, 21.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Small";
            Assert.AreEqual(expected, ipostage.Category,"Small Category Test failed");
        }
        [TestMethod]
        public void RejectTestCategory_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(52.00M, 21.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Reject";
            Assert.AreEqual(expected, ipostage.Category, "Reject Category Test failed");
        }
        [TestMethod]
        public void MediumTestCategory_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(8.00M, 1700.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Medium";
            Assert.AreEqual(expected, ipostage.Category, "Medium Category Test failed");
        }
        [TestMethod]
        public void LargeTestCategory_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(8.00M, 2600.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Large";
            Assert.AreEqual(expected, ipostage.Category, "Large Category Test failed");
        }
        [TestMethod]
        public void LargeTestCategoryNotEqual_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(8.00M, 2600.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Small";
            Assert.AreNotEqual(expected, ipostage.Category, "Large Category Test failed");
        }
        [TestMethod]
        public void MediumTestCategoryNotEqual_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(8.00M, 1700.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Large";
            Assert.AreNotEqual(expected, ipostage.Category, "Medium Category Test failed");
        }

        [TestMethod]
        
        public void RejectTestCategoryNotEqual_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(52.00M, 21.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Medium";
            Assert.AreNotEqual(expected, ipostage.Category, "Reject Category Test failed");
        }
        [TestMethod]
        public void HeavyTestCategoryNotEqual_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(12.00M, 213.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Reject";
            Assert.AreNotEqual(expected, ipostage.Category, "HeavyTestCategory_Test, failed");
        }
        [TestMethod]
        public void SmallTestCategoryNotEqual_Test()
        {
            string factory = Helpers.HelperClass.GetPostageClass(10.00M, 21.00M);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            string expected = "Large";
            Assert.AreNotEqual(expected, ipostage.Category, "Small Category Test failed");
        }

    }
}
