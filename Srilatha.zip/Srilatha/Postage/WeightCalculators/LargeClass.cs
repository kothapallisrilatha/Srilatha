﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public class LargeClass:Ipostage
    {
        public string Category
        {
            get { return "Large"; }
        }

        public void calculate(decimal weight, decimal volume)
        {
            decimal price = volume * 0.03M;
            Console.WriteLine("Cost: "+price);
        }
    }
}
