﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public class RejectClass:Ipostage
    {
        public string Category
        {
            get { return "Reject"; }
        }
       

      

        public void calculate(decimal weight, decimal volume)
        {
            Console.WriteLine("Cost: N/A ");
        }
    }
}
