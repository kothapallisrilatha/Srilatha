﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public class SmallClass : Ipostage
    {
        public string Category
        {
            get { return "Small"; }
        }

        public void calculate(decimal weight, decimal volume)
        {
            decimal price = volume * 0.05M;
            Console.WriteLine("Cost: " + price);
        }
    }
}
