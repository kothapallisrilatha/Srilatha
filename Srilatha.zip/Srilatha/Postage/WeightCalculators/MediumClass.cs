﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public class MediumClass:Ipostage
    {
        public string Category
        {
            get { return "Medium"; }
        }

        public void calculate(decimal weight, decimal volume)
        {
            decimal price = volume * 0.04M;
            Console.WriteLine("Cost: " + price);
        }
    }
}
