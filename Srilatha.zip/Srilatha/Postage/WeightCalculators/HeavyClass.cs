﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public class HeavyClass:Ipostage
    {
        public string Category
        {
            get { return "Heavy"; }
        }
      

        public void calculate(decimal weight, decimal volume)
        {
            decimal price = weight * 15;
            Console.WriteLine("Cost: " + price);
        }

        
    }
}
