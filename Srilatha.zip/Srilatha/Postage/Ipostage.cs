﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
   public interface Ipostage
    {
        string Category
        {
            get;
        }
        //bool CanHandle(decimal weight, decimal volume);
        void calculate(decimal weight,decimal volume);
    }
}
