﻿using Postage.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter Weight:");
            string weight = Console.ReadLine();
            Console.Write("Enter Height :");
            string height = Console.ReadLine();
            Console.Write("Enter Width:");
            string width = Console.ReadLine();
            Console.Write("Enter Depth:");
            string depth = Console.ReadLine();
            Console.WriteLine("-------------------");
            decimal volume = Convert.ToDecimal(height) * Convert.ToDecimal(width) * Convert.ToDecimal(depth);
            string factory = HelperClass.GetPostageClass(Convert.ToDecimal(weight), volume);
            Ipostage ipostage = PostageFactory.GetFactoryInstance(factory);
            Console.WriteLine("Category:  " + ipostage.Category);
            ipostage.calculate(Convert.ToDecimal(weight), volume);
            Console.ReadLine();



        }
        

    }
   
}
