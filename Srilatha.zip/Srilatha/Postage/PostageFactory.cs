﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage
{
    public static class PostageFactory
    {
        public static Ipostage GetFactoryInstance(string factoryclass)
        {
            switch (factoryclass.ToUpper())
            {
                case "HEAVY":
                    return new HeavyClass();
                case "REJECT":
                    return new RejectClass();
                case "SMALL":
                    return new SmallClass();
                case "MEDIUM":
                    return new MediumClass();
                case "LARGE":
                    return new LargeClass();
                default:
                    return null;
            }
        }
    }
}
