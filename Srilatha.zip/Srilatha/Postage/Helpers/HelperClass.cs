﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Postage.Helpers
{
    public class HelperClass
    {
        public static string GetPostageClass(decimal weight, decimal volume)
        {
            string factory = string.Empty;

            if (weight > 10.00M && weight <= 50.00M)
            {
                return "Heavy";
            }
            else if (weight > 50.00M)
            {
                return "Reject";
            }
            else if (weight <= 10.00M && volume < 1500.00M)
            {
                return "Small";
            }
            else if (weight <= 10.00M && (volume >= 1500.00M && volume < 2500))
            {
                return "Medium";
            }
            else if (weight <= 10.00M && volume >= 2500.00M)
            {
                return "Large";
            }

            return factory;
        }
    }
}
